create database CSclub;
use CSclub;

create table Student(
st_id numeric (10)primary key,
F_name varchar(20),
M_name varchar(20),
L_name varchar(20),
S_level int,
gpa double ,
Email varchar(40),
phone numeric (10)
);
alter table Student add column StudentParticipation numeric (20);

insert into Student  values(2190005693,'Assail','Saeed','Alyami',6,4.5,'219000693@iau.edu.com',0594757493,9);
insert into Student  values(2190003739,'Sheikah','Saad','Alqahtani',6,4.5,'2190003739@iau.edu.com',0594757493,8);
insert into Student  values(2190003925,'Razan','Ayed','Algarni',6,4.5,'2190003925@iau.edu.com',0594757493,13);
insert into Student  values(2190007364,'Bashayer','FatehUdeen','Allail',6,4.5,'2190007364@iau.edu.com',0594757493,15);
insert into Student  values(2190005556,'Esra','Muhammed','Alyami',6,4.5,'2190005556@iau.edu.com',0594757493,10);


select * from Student;



create table Teacher(
NO_T numeric (10) primary key,
f_name varchar(15),
l_name varchar(15),
pass varchar(10)

);

insert   into   Teacher    values(1,'Reem','Alshammari',1111);
insert   into   Teacher    values(2,'Hessa','Almutairi',2222);
insert   into   Teacher    values(3,'Maha','Alghamdi',3333);
insert   into   Teacher    values(4,'Fatimah','saleh',4444);
insert   into   Teacher    values(5,'Norah','Alnaim',5555);
insert   into   Teacher    values(6,'Thowiba','Ahmed',6666);
insert   into   Teacher    values(7,'Dhabia','Albuainain',7777);
insert   into   Teacher    values(8,'Enas','ElSharawey',8888);
insert   into   Teacher    values(9,'Azza','Abdo Ali',9999);
insert   into   Teacher    values(10,'Salma','ALbelali',1010);
insert   into   Teacher    values(11,'Norah','Alqahtani',1011);
insert   into   Teacher    values(12,'Linda','Ali',1012);
insert   into   Teacher    values(13,'Samirah','Albalhareh',1013);
insert   into   Teacher    values(14,'Tagreed',' Balhareh',1014);
insert   into   Teacher    values(15,'Rania', 'Tabedi',1015);
insert   into   Teacher    values (16,'Nagla',' Elsidding',1016);
insert   into   Teacher    values (17,'Hanaa', 'Moursy' ,1017);

select * from Teacher;


create table Request 
( NO_Re numeric(5) Primary key, 
  fname char(10),
  lname char(10),
  Req_Email varchar (45),
  Req_type varchar (45),
  NO_Teacher numeric,
foreign key (NO_Teacher) references Teacher (NO_T) 
);

insert into Request values (1, 'Khaled', 'Alali', 'KhaledAlali453@gmail.com', 'present',15);
insert into Request values (2, 'Malak', 'Almtari', 'MalakAlmtari45@gmail.com', 'attendance ',3);   
insert into Request values (3, 'Yaser', 'Alosefer', 'YaserAlosefer234@gmail.com', 'present',11);
insert into Request values (4, 'Sara', 'Alkhaldi', 'SaraAlkhaldi123@gmail.com', 'attendance ',6);
insert into Request values(5,'Assail','Alyami','2190005693@iau.edu.sa','present',10);
insert into Request values(6,'Sheikah','ALqahtani','2190003739@iau.edu.sa','present',2);


select * from Request;


create table Event(
Event_id numeric (10) not null ,
Event_name varchar (45),
Event_type varchar(45),
F_name varchar(20),
L_name varchar(20),
event_date date,
place varchar(45) ,
NO_T numeric (10) primary key);


insert into Event values (1,'workshop','Andorid application',  'sayer', 'Algehny','2021-03-03','Zoom',2);
insert into Event values (2,'workshop','Arduino microontrollers',  'meshael', 'Almtrafy','2021-03-23','Zoom',3);
insert into Event values( 3, 'worksop', 'Programming in Java', 'Reem','Alshammari','2021-04-23','Zoom',5);
insert into Event values(4,'worksop', 'Artificial intelligence','Dhabia','Albuainain','2021-04-13','Zoom',1);

select * from Event;


create table member_req(
st_id numeric(10) references Student (st_id),
T_id  numeric(10) references Teacher (NO_T),
req_type varchar (50) not null 
);

select * from member_req;


create table manage(
TE_id  numeric(10) references Teacher (NO_T),
event_id numeric (10) not null references Event (Event_id)
);

select * from manage;

/* Delete tuples  */
delete from Student where st_id='2190005556';

/* Update tuples */
update Student  set S_level=7 where st_id='2190003925'; 


/* Procedures  */
Delimiter $$
CREATE PROCEDURE name_ins( In n numeric )
BEGIN

SELECT * 
from Request
 where NO_Teacher=n  ; 
END;$$
Delimiter ;

delimiter ;

CALL name_ins(11);

/* Distinct operation */
select distinct F_name from Student where F_name in (select fname from Request)  ;

/* View and LIKE Operator*/
create view v1  as select fname
from Request
where Req_Email like '%edu.sa';
select * from v1;

/* Assertion */

Create Assertion AS1
Check ( 
Not exists 
( Select * 
from Request 
Where Req_no>200 ) );



/* COUNT() Function */
select Req_type,count(NO_Re)
from Request
group by Req_type;

/* EXISTS Operator  (complex query )*/

SELECT T.f_name, T.l_name
FROM Teacher AS T
WHERE EXISTS
( SELECT *
FROM Event AS E
WHERE T.f_name = E.F_name AND T.l_name =E.L_name
);


/* Sonchema Modificati (add column )  and If statment function */
select F_name,L_name,if ( StudentParticipation >=10 ,'Active Student', 'Unreactive Student') StudentParticipation from Student;

/* index */
use CSclub;
create  index i_name
on Teacher (f_name  ASC );
select * from Teacher order by f_name;